.. aria2 documentation master file, created by
   sphinx-quickstart on Tue Apr 10 21:34:06 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Aria2 Manual
============

Contents:

.. toctree::
   :maxdepth: 2

   aria2c
   README
   libaria2
   technical-notes
